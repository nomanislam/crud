<?php 


	require 'db_connect.php';
	

// Delete Data


	if(isset($_GET['del'])){
		$id = $_GET['del'];
		$sql = "DELETE FROM crud_table WHERE id = $id";
		mysqli_query($conn, $sql);
	}





?>






<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Registar Page</title>
  </head>
  <body>
    
	
	
	



<!-- html coding start -->


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="table-head">
				<h2 class="mt-3 p-5 text-center text-warning"><b>Display All Data</b></h2>
			</div>
			<table class="table table-hover">
				<thead class="bg-success text-white text-center">
					<tr>
						<th scope="col">ID</th>
						<th scope="col">Name</th>
						<th scope="col">Email</th>
						<th scope="col">Passowrd</th>
						<th scope="col">Delete</th>
						<th scope="col">UpDate</th>
					</tr>
				</thead>
				<tbody class="text-center">


				<?php 


				require 'db_connect.php'; // Database Connected...

	
				$sql = "SELECT * FROM crud_table";
	
				$query = mysqli_query($conn,$sql);
	
				while($result = mysqli_fetch_assoc($query)){
		
	

	
	
?>
					<tr>
						<th scope="row"><?php echo $result["id"]; ?></th>
						<td><?php echo $result['name']; ?></td>
						<td><?php echo $result['email']; ?></td>
						<td><?php echo $result['password']; ?></td>
						<td>
							<a href="?del=<?php echo $result['id'] ?>" 
							class="btn btn-danger">Delete</a>
						</td>
						<td>
							<a href="update.php?upd=<?php echo $result['id'] ?>" 
							class="btn btn-success">UpDate</a>
						</td>
					</tr>
					
					
				<?php } ?>

				</tbody>
			</table>
		</div>
	</div>
</div>













    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>



